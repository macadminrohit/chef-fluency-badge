import requests

def fetch_api_data():
    api_urls = [
        
        'https://sys-dist-aurora-products-v1.api.uat.cloud.invesco.com/health'
    ]

    responses = []
    for api_url in api_urls:
        response = requests.get(api_url)
        if response.status_code == 200:
            api_name = "_".join(api_url.replace("https://", "").split("."))
            responses.append((api_name, response.json()))
        else:
            responses.append((api_name, None))

    return responses

def convert_to_prometheus(data):
    prometheus_data = ""
    for api_name, json_data in data:
        if json_data:
            if "entries" in json_data:
                # existing logic for publicapis.org
                categories = {}
                auth_types = {}
                for entry in json_data["entries"]:
                    categories[entry['Category']] = categories.get(entry['Category'], 0) + 1
                    auth_types[entry['Auth']] = auth_types.get(entry['Auth'], 0) + 1
                
                for category, count in categories.items():
                    prometheus_data += f'api_category_count{{api="{api_name}", category="{category}"}} {count}\n'
                
                for auth_type, count in auth_types.items():
                    prometheus_data += f'api_auth_type_count{{api="{api_name}", auth_type="{auth_type}"}} {count}\n'
            else:
                # new logic for sys-dist-aurora-products-v1
                prometheus_data += f'api_health_status{{api="{api_name}", status="{json_data["status"]}"}} 1\n'
                prometheus_data += f'api_product_db_status{{api="{api_name}", database="{json_data["productDb"]["database"]}", status="{json_data["productDb"]["status"]}"}} 1\n'
                prometheus_data += f'api_product_db_hello_metric{{api="{api_name}", database="{json_data["productDb"]["database"]}"}} {json_data["productDb"]["hello"]}\n'
        else:
            prometheus_data += f'api_response{{api="{api_name}"}} 0\n'
    return prometheus_data

def lambda_handler(event, context):
    try:
        data = fetch_api_data()
        if data:
            prometheus_data = convert_to_prometheus(data)
            return {
                "statusCode": 200,
                "body": prometheus_data,
                "headers": {
                    'Content-Type': 'text/plain'
                }
            }
        else:
            return {
                "statusCode": 500,
                "body": "Failed to fetch data"
            }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": str(e)
        }
