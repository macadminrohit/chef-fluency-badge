import os
import requests
from flask import Flask, request, jsonify

app = Flask(__name__)

# Function to fetch data from the APIs
def fetch_api_data():
    api_urls = [
        os.getenv('API_URL'),
        'https://sys-dist-aurora-products-v1.api.uat.cloud.invesco.com/health'
    ]
    
    responses = []
    for api_url in api_urls:
        response = requests.get(api_url)
        if response.status_code == 200:
            responses.append(response.json())
        else:
            responses.append(None)
    
    return responses

# Function to convert JSON data to Prometheus format
def convert_to_prometheus(json_data):
    prometheus_data = ""
    for data in json_data:
        if data:
            for key, value in data.items():
                prometheus_data += f"{key} {value}\n"
    return prometheus_data

# Flask route to expose the data as a metrics endpoint
@app.route('/metrics', methods=['GET'])
def metrics():
    json_data = fetch_api_data()
    if json_data:
        prometheus_data = convert_to_prometheus(json_data)
        return prometheus_data, 200, {'Content-Type': 'text/plain'}
    else:
        return "Failed to fetch data", 500

# Main function for AWS Lambda
def lambda_handler(event, context):
    from werkzeug.serving import run_simple
    run_simple('localhost', 5000, app)
